// Cloudflare Pages Function : POST /api/subscribe  (binding D1 requis : DB)
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{"Content-Type":"application/json"}});
const EMAIL=/^[^@\s]+@[^@\s]+\.[^@\s]+$/;
async function hash(t){const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(t));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("").slice(0,32)}
export async function onRequestPost({request,env}){
  const origin=request.headers.get("Origin");
  if(origin&&new URL(origin).host!==new URL(request.url).host)return J({error:"origin"},403);
  let d;try{d=await request.json()}catch{return J({error:"json"},400)}
  const lang=["fr","kr","en"].includes(d.lang)?d.lang:"fr";
  let kind,contact,prompts=null,body=null;
  if(typeof d.email==="string"){kind="email";contact=d.email.trim().toLowerCase().slice(0,254);if(!EMAIL.test(contact))return J({error:"email"},400)}
  else if(typeof d.whatsapp==="string"){kind="whatsapp";contact=d.whatsapp.trim().slice(0,30);
    if(contact.replace(/\D/g,"").length<8||!/^\+?[\d\s().-]+$/.test(contact))return J({error:"phone"},400);
    prompts=JSON.stringify((Array.isArray(d.prompts)?d.prompts:[]).slice(0,40).map(x=>String(x).slice(0,120)));
    body=typeof d.text==="string"?d.text.slice(0,6000):null}
  else return J({error:"payload"},400);
  const now=Date.now(),ip=await hash((request.headers.get("CF-Connecting-IP")||"?")+(env.SALT||"kia"));
  const n=await env.DB.prepare("SELECT COUNT(*) c FROM leads WHERE ip_hash=? AND created_at>?").bind(ip,now-600000).first();
  if(n&&n.c>=5)return J({error:"rate"},429);
  await env.DB.prepare("INSERT OR IGNORE INTO leads(kind,contact,lang,prompts,body,ip_hash,created_at) VALUES(?,?,?,?,?,?,?)").bind(kind,contact,lang,prompts,body,ip,now).run();
  return J({ok:true});
}
export const onRequest=()=>J({error:"method"},405);
